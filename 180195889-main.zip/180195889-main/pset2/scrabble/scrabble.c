#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>

int wordScore(string word);

int main(void)
{
    // Get player 1 word and send to scoring function
    string word1 = get_string("Enter your word, Player 1: ");
    int score1 = wordScore(word1);

    // Get player 2 word and send to scoring function
    string word2 = get_string("Enter your word, Player 2: ");
    int score2 = wordScore(word2);

    // Compare scores and return winner
    if(score1 > score2)
    {
        printf("Player 1 wins!\n");
    }

    else if(score1 < score2)
    {
        printf("Player 2 wins!\n");
    }

    else
    {
        printf("Tie!\n");
    }
}

int wordScore(string word)

{
    // Create array containing letter score values
    int pointValues[26] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3,
         1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

    int score = 0;

    // Get length of player's word
    int index = strlen(word);

    // Run loop to check if word is upper or lower case, reduce by ascii value for A or a
    for(int i = 0; i < index; i++)
    {
        if(isupper(word[i]))
        {
            score += pointValues[(int)word[i] - 65];
        }

        else if(islower(word[i]))
        {
            score += pointValues[(int)word[i] - 97];
        }
    }
    printf("%i\n", score);

    return score;
}
