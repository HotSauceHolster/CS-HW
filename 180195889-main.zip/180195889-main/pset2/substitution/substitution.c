#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

int keyValidation(string cipher);

int main(int argc, string argv[])
{
    string key = argv[1];
    // Check for valid number of CL arguments and check key validity
    if (argc != 2 || keyValidation(key))
    {
        printf("Error: expected key of 26 unique characters via command line argument.\n");
        return 1;
    }
    // Get plaintext string from user
    string rawtext = get_string("plaintext: ");
    // Initialize variable for length of string and create char array of same length
    int textLength = strlen(rawtext);
    char substituted[textLength + 1];

    int pos;
    // Loop through length of plaintext
    for (int i = 0; i < textLength; i++)
    {
        // If current character is upper case, insert corresponding key uppercased
        if (isupper(rawtext[i]))
        {
            pos = (int) rawtext[i] - 'A';
            substituted[i] = key[pos];
            substituted[i] = toupper(substituted[i]);
        }
        // If current character is lower case, insert corresponding key lowercased
        else if (islower(rawtext[i]))
        {
            pos = (int) rawtext[i] - 'a';
            substituted[i] = key[pos];
            substituted[i] = tolower(substituted[i]);
        }
        // If current character is whitespace, punctuation or digit, copy without change
        else if (isspace(rawtext[i]) || ispunct(rawtext[i]) || isdigit(rawtext[i]))
        {
            substituted[i] = rawtext[i];
        }
    }
    // Add NUL character to end of string
    substituted[textLength] = '\0';
    printf("ciphertext: %s", substituted);
    printf("\n");
    return 0;
}

int keyValidation(string k)
{
    // Validate key length
    if (strlen(k) != 26)
    {
        printf("Key is not 26 characters in length.");
        return 1;
    }
    else
    {
        int checkKey[26];
        for (int i = 0; i < strlen(k); i++)
        {
            // Validate for alphabetic characters and no duplicates
            if (isalpha(k[i]))
            {
                checkKey[i] = toupper(k[i]);
                for (int j = 0; j < i; j++)
                {
                    if (checkKey[i] == checkKey[j])
                    {
                        printf("Key contains duplicated characters.");
                        return 1;
                    }
                }
            }
            else
            {
                printf("Error: Key contains non alphabetic characters.");
                return 1;
            }
        }
        return 0;
    }
}
