#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

float clindex(string text);

int main(void)
{
    // Get input from user
    string s = get_string("Enter a reading sample: ");
    // Run function to get Coleman-Liau index
    float ind = clindex(s);
    // Round to nearest grade level
    ind = round(ind);
    // Print appropriate grade level based on index
    if (ind < 1)
    {
        printf("Before Grade 1\n");
    }
    else if (ind >= 1 && ind <= 16)
    {
        printf("Grade %i\n", (int) ind);
    }
    else
    {
        printf("Grade 16+\n");
    }
}

float clindex(string text)
{
    // Get length of text and initialize variables for loop and CLI formula
    int l = strlen(text);
    int i = 0;
    int letters = 0;
    int sentences = 0;
    int words = 0;

    // Loop through string
    while (i < l)
    {
        // Incrementing letters for alphanumeric characters
        if (isalnum(text[i]))
        {
            letters++;
            i++;
        }
        // Incrementing words if punctuaion other than - or '
        else if (ispunct(text[i]) && (int) text[i] != 39 && (int) text[i] != 45 && (int) text[i] != 34)
        {
            words++;
            // Incrementing sentences if sentence ending punctuaion
            if ((int) text[i] == 46 || (int) text[i] == 33 || (int) text[i] == 63)
            {
                sentences++;
                if (isspace(text[i + 1]))
                {
                    i++;
                }
            }
            i++;
        }
        // Incrementing words if character prior to whitespace was
        else if (isspace(text[i]))
        {
            if (isalnum(text[i - 1]))
            {
                words++;
            }
            i++;
        }
        else
        {
            i++;
        }
    }
    float index = .0588 * (((float) letters / (float) words) * 100.0) -
                  .296 * (((float) sentences / (float) words) * 100.0) - 15.8;
    return index;
}
