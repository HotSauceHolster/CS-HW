#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <cs50.h>

int main(void)
{
    //printf("What's your name?"); Oops don't need that.
    string s = get_string("What's your name? ");
    printf("Hello, %s \n", s);
}
