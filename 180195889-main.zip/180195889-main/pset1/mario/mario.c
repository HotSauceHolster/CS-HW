#include <cs50.h>
#include <stdio.h>

void left_half(int, int);
void right_half(int);

int main(void)
{
    // Get and validate user input
    int height;
    do
    {
        height = get_int(
            "How tall do you want your pyramid? (please enter between 1-8 levels in height) ");

        if (height > 8 || height < 1)
        {
            printf("Please enter a valid pyramid height.\n");
        }
    }
    while (height > 8 || height < 1);

    // Loop for each layer of pyramid
    for (int l = 0; l < height; l++)
    {
        // Print left half
        left_half(height, l);
        // Print gap between
        printf("  ");
        // Print right half
        right_half(l);
        // Go to next line
        printf("\n");
    }
}

// Function to print left half of pyramid
void left_half(int h, int layer)
{
    for (int i = 0; i < h; i++)
    {
        if (i >= h - 1 - layer)
        {
            printf("#");
        }
        else
        {
            printf(" ");
        }
    }
}

// Function to print right half of pyramid
void right_half(int layer)
{
    for (int i = 0; i < layer + 1; i++)
    {
        printf("#");
    }
}
