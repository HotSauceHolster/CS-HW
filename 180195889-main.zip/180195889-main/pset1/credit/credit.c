#include <cs50.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int checksum(long);

int main(void)
{
    // Initialize card length checkers
    long amex = 10000000000000;
    long mc = 100000000000000;
    long visa1 = 1000000000000;
    long visa2 = 1000000000000000;

    // Get user input
    long ccnum = get_long("Please enter a credit card number: ");

    // Run Luhn's algorithm - if valid proceed to check card type
    if (checksum(ccnum))
    {
        if (ccnum / amex == 34 || ccnum / amex == 37)
        {
            printf("AMEX\n");
        }

        else if (ccnum / mc >= 51 && ccnum / mc <= 55)
        {
            printf("MASTERCARD\n");
        }

        else if (ccnum / visa1 == 4 || ccnum / visa2 == 4)
        {
            printf("VISA\n");
        }

        else
        {
            printf("INVALID\n");
        }
    }
    // Return invalid if Luhn's algorithm check fails
    else
    {
        printf("INVALID\n");
    }
}

int checksum(long cc)
{
    int length = 1;
    long tempnum = cc;
    int odds = 0;
    int evens = 0;

    // Find length of card number
    while (tempnum / 10 != 0)
    {
        tempnum = tempnum / 10;
        length++;
    }

    long checknum = cc;

    int testlength = length / 2;

    // Loop through number a pair of digits at a time for half the length (plus 1 for odd card lengths)
    for (int i = 0; i < testlength + 1; i++)
    {
        odds += checknum % 10;
        checknum = checknum / 10;
        if ((checknum % 10) * 2 >= 10)
        {
            int dig1 = (checknum % 10) * 2;
            int dig2 = dig1 % 10;
            int dig3 = dig1 / 10;
            evens += dig2 + dig3;
        }
        else
        {
            evens += checknum % 10 * 2;
        }

        checknum = checknum / 10;

        // Checking the math
        printf("%i ", odds);
        printf("%i\n", evens);
    }
    int sum = odds + evens;
    printf("%i\n", sum);

    // Check for satisfaction of Luhn's Algo - sum ends in 0
    if (sum % 10 == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
